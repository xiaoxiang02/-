'use strict';
const db = uniCloud.database()
exports.main = async (event, context) => {

	const collection = db.collection('uni-id-users');
	const $ = db.command.aggregate

	//查询用户的记账列表
	let res = await collection.aggregate()
		.match({
			_id: event.id
		})
		.lookup({
			from: 'bill',
			localField: '_id',
			foreignField: 'user_id',
			as: 'billList',
		})
		.project({
			_id: 1,
			billList: 1,
		})
		.end()


	//客户端上传的参数
	console.log(JSON.stringify(res))

	//返回数据给客户端
	return {
		code: 200,
		msg: "执行成功",
		data: res.data
	}
};