<template>
	<view class="container">
		<u-empty v-if="totalList.length == 0" text="没有记账历史记录" mode="history"></u-empty>
		<view v-else class="count" v-for="(item, index) in totalList" :key="index">
			<view class="in" v-if="item.type == 0">
				<text>收入</text>
				<view>{{item.total}}</view>
			</view>
			
			<view class="out" v-if="item.type == 1">
				<text>支出</text>
				<view>{{item.total}}</view>
			</view>
		</view>
		<unicloud-db ref="udb" v-slot:default="{data, pagination, loading, hasMore, error}" :collection="collectionList"
			field="amount,remarks,created_at" where="user_id == $cloudEnv_uid">
			<view v-if="error">{{error.message}}</view>
			<view v-else-if="data">
				<uni-list>
					<uni-list-item v-for="(item, index) in data" :key="index" showArrow :clickable="true"
						@click="handleItemClick(item._id)">
						<template v-slot:body>
							
							<view class="list-box-children">
								<img src="../../../static/icon/jz.png" class="icon">
								<view class="box-left">
									{{item.remarks}}
								</view>
								<view class="box-right">
									￥{{item.amount}}
								</view>
								<view class="box-end">
									<uni-dateformat :threshold="[0, 0]" :date="item.created_at" format="yyyy-MM-dd">
									</uni-dateformat>
								</view>
							</view>
						</template>
					</uni-list-item>
				</uni-list>
			</view>
			<uni-load-more :status="loading?'loading':(hasMore ? 'more' : 'noMore')"></uni-load-more>
		</unicloud-db>
		<uni-fab :pattern="pattern" ref="fab" horizontal="right" vertical="bottom" :pop-menu="false"
			@fabClick="fabClick" />
	</view>
</template>

<script>
	const db = uniCloud.database()
	export default {
		data() {
			return {
				pattern: {
					color: 'gray',
					backgroundColor: '#FFFFFF',
					selectedColor: '#42b479',
					buttonColor: '#42b479'
				},
				collectionList: 'bill',
				loadMore: {
					contentdown: '',
					contentrefresh: '',
					contentnomore: ''
				},
				totalList: [],
			}
		},
		onLoad() {
			var that = this
			db.collection('bill')
				.where('user_id == $cloudEnv_uid')
				.groupBy('type,user_id')
				.groupField('sum(amount) as total')
				.get().then(res => {
					this.totalList = res.result.data;
				})
		},

		onShow() {

		},

		onPullDownRefresh() {
			this.$refs.udb.loadData({
				clear: true
			}, () => {
				uni.stopPullDownRefresh()
			})
		},

		onReachBottom() {
			this.$refs.udb.loadMore()
		},


		methods: {
			handleItemClick(id) {
				uni.navigateTo({
					url: '/pages/bill/detail?id=' + id
				})
			},

			fabClick() {
				// 打开新增页面
				uni.navigateTo({
					url: '/pages/bill/add',
					events: {
						// 监听新增数据成功后, 刷新当前页面数据
						refreshData: () => {
							this.$refs.udb.loadData({
								clear: true
							})
						}
					}
				})
			},
		}
	}
</script>

<style lang="scss">
	.container {
		height: 100vh;
		background: #f7f7f7;
	}

	.count {
		padding-top: 10px;
		width: 50%;
		display: inline-block;
		height: 80px;
		text-align: center;
		font-size: 18px;
		color: #fff;
		background-color: #42b479;

		.in,
		.out {
			view {
				margin-top: 10px;
			}
		}
	}

	.list-box-children {
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-orient: horizontal;
		-webkit-box-direction: normal;
		-webkit-flex-direction: row;
		flex-direction: row;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		position: relative;
		box-sizing: border-box;
		width: 100%;
		padding: 20rpx 0rpx;
		font-size: 28rpx;
		line-height: 50rpx;
		color: #000000;
		background-color: #fff;
		text-align: left;

		.box-left {
			width: auto;
			margin-left: 3px;
			font-weight: 500;
			font-size: 30rpx;
		}

		.box-right {
			margin-left: 5px;
			overflow: hidden;
			text-align: right;
			vertical-align: middle;
			color: #878a8f;
			font-size: 30rpx;
		}

		.box-end {
			position: absolute;
			margin-left: 220px;
			text-align: right;
			vertical-align: middle;
			color: #42b479;
			font-size: 30rpx;
		}
	}

	.icon {
		width: 25px;
		height: 25px;
	}
</style>
