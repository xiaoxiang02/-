<template>
	<view class="container">
		<view class="userInfo">
			<image class="header-icon" src="../../../static/icon/heard.png"></image>
			<view class="info">
				<view>{{ nickName }}{{ userName }}</view>
			</view>
		</view>
		<view class="number">
			<view class="day">
				<text>{{day}}</text>
				<view>使用天数</view>
			</view>
			<view class="count_day">
				<text>{{count_day}}</text>
				<view>总记账天数</view>
			</view>
			<view class="count">
				<text>{{count}}</text>
				<view>总记账笔数</view>
			</view>
		</view>

		<view class="footer">
			<button @click="logout">注销</button>
		</view>
	</view>
</template>

<script>
	const db = uniCloud.database()
	export default {
		data() {
			return {
				nickName:'',
				userName:'',
				day: 0,
				count_day: 0,
				count: 0,
			}
		},

		onLoad() {
			var that = this
		},

		//如果进入小程序不跳转登陆页面，当点击我的会先判断用户是否登陆
		onShow() {
			this.getCount();
			this.getUserInfo();
			
			uni.getStorage({
				key: 'uni_id_token',
				success: function(res) {
					console.log('用户已登录');
				},
				fail: function(res) {
					console.log('用户未登录');
					uni.navigateTo({
						url: '/pages/login/login',
					})
				}
			})
		},


		methods: {
			//获取用户的信息和使用天数
			getUserInfo(id) {
				uniCloud.callFunction({
					name: 'user',
					//传值给云函数的event
					data: {
						id: uniCloud.getCurrentUserInfo().uid
					}
				}).then(res => {
					//用户信息
					this.nickName = res.result.data[0].nickname
					this.userName = res.result.data[0].username
					//使用天数
					var register_date = res.result.data[0].register_date
					var time = new Date().getTime();
					this.day = parseInt((time - register_date) / (1000*3600*24))
					console.log(res)
				}).catch(err => {
					console.log(err)
				})
			},

			//获取用户的记账数量
			getCount(user_id) {
				uniCloud.callFunction({
					name: 'bill',
					//传值给云函数的event
					data: {
						user_id: uniCloud.getCurrentUserInfo().uid
					}
				}).then(res => {
					this.count = res.result.data[0].count
					console.log(res)
				}).catch(err => {
					console.log(err)
				})
			},

			// 清空本地登录的内容
			logout() {
				uni.showModal({
					title: '提示',
					content: '确定退出登录吗？',
					success: function(res) {
						if (res.confirm) {
							console.log('用户点击确定');
							uni.clearStorage({
								success: function() {
									uni.reLaunch({
										url: "../../login/login"
									})
								}
							});

						} else if (res.cancel) {
							console.log('用户点击取消');
						}
					}.bind(this) //可处理uni.shuowModal的异步（即拿不到data里面数据的解决办法）
				})
			}
		},
	}
</script>

<style lang="scss">
	.container {
		height: 100vh;
		background: #f7f7f7;
	}

	.userInfo {
		color: #fff;
		background: #42b479;
		width: 100%;
		height: 110px;

		.header-icon {
			border: 5upx solid #fff;
			border-radius: 50%;
			width: 130upx;
			height: 130upx;
			margin: 15px 0 0 20px;
		}

		.info {
			position: absolute;
			display: inline-block;
			width: 100px;
			height: 100%;
			margin: 32px 0 0 20px;
		}
	}

	.number {
		background: #fff;
		display: flex;

		.day,
		.count_day,
		.count {
			width: 75px;
			margin: 20px 0 25px 37.5px;
			text-align: center;

			text {
				font-size: 23px;
			}

			view {
				color: #737373;
				font-size: 13px;
			}

		}

	}

	.footer {
		margin: 80px 37.5px;
		width: 80%;

		button {
			background: #42b479;
			color: white;
		}
	}
</style>
