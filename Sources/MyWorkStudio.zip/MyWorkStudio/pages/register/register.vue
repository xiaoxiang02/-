// An highlighted block
<template>
	<view class="content">
		<view class="avatorWrapper">
			<view class="avator">
				<image class="img" src="../../static/jz.png" mode="widthFix"></image>
			</view>
		</view>
		<view class="form">
			<uni-forms ref="form" :modelValue="formData">
				<uni-forms-item name="nickname">
					<input class="input" type="text" value="" v-model="formData.nickname" placeholder="请输入名字" />
				</uni-forms-item>
				<uni-forms-item name="iphone">
					<input class="input" type="text" value="" v-model="formData.iphone" placeholder="请输入手机号" />
				</uni-forms-item>
				<uni-forms-item name="password">
					<input class="input" type="password" value="" v-model="formData.password" placeholder="请输入密码" />
				</uni-forms-item>
				<uni-forms-item name="confirmPassword">
					<input class="input" type="password" value="" v-model="formData.confirmPassword" placeholder="请再次输入密码" />
				</uni-forms-item>
			</uni-forms>

			<view class="loginBtn" @click="submit">
				<text class="btnValue">注册</text>
			</view>
		</view>
	</view>
</template>



<script>
	const db = uniCloud.database();
	export default {
		data() {
			return {
				formData: {
					nickname: '黄杏',
					iphone: '18277901106',
					password: '123456A@a',
					confirmPassword: '123456A@a',
				},
				rules: {
					nickname: {
						rules: [{
							required: true,
							errorMessage: '姓名不能为空',
						}, {
							validateFunction: function(rule, value, data, callback) {
								let nicknameReg = /^\S{2,}$/
								if (!nicknameReg.test(value)) {
									callback('至少不少于4位字符')
									return false
								}
							}
						}]
					},
					iphone: {
						rules: [{
							required: true,
							errorMessage: '请输入注册手机号码'
						}, {
							validateFunction: function(rule, value, data, callback) {
								let iphoneReg = /^[0-9]{11,11}$/
								if (!iphoneReg.test(value)) {
									callback('手机号码格式不正确，请重新填写')
									return false
								}
							}
						}]
					},
					password: {
						rules: [{
							required: true,
							errorMessage: '登录密码不能为空',
						}, {
							validateFunction: function(rule, value, data, callback) {
								let passwordReg = /^.*(?=.{8,})(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[!@#$%^&*? ]).*$/
								if (!passwordReg.test(value)) {
									callback('密码最少8位，包括大、小写字母，数字，特殊字符')
									return false
								}
							}
						}]
					},
					confirmPassword: {
						rules: [{
							required: true,
							errorMessage: '重复密码不能为空',
						}, {
							validateFunction: function(rule, value, data, callback) {
								if (value != data.password) {
									callback('密码与重复密码不匹配')
									return false
								}
							}
						}]
					},
				},
			}
		},
		onLoad() {

		},

		methods: {
			onReady() {
				this.$refs.form.setRules(this.rules)
			},
			submit() {
				this.$refs.form.validate().then(res => {
					console.log('表单数据信息：', res);
					this.register(res)
				}).catch(err => {
					console.log('表单错误信息：', err);
				})
			},

			req(action, params) {
				uni.showLoading({
					title: '注册中'
				})
				return new Promise((resolve) => {
					uniCloud.callFunction({
						name: 'user-center',
						data: {
							action,
							params
						},
						success: res => {
							uni.hideLoading()
							resolve(res.result);
						},
						fail: res => {
							resolve(res)
						}
					})
				})
			},

			register(e) {
				this.req("register", {
					nickname: this.formData.nickname,
					username: this.formData.iphone,
					password: this.formData.password,
				}).then(res => {
					console.log(res)
					uni.setStorageSync('uni_id_token', res.token)
					uni.redirectTo({
						url: '/pages/login/login'
					});
				})
				console.log("跳转提醒")
			},

		}
	}
</script>



<style>
	.content {
		width: 100vw;
		height: 100vh;
	}

	.avatorWrapper {
		margin-top: 16px;
		height: 30vh;
		width: 100vw;
		display: flex;
		justify-content: center;
		align-items: flex-end;
	}

	.avator {
		width: 300upx;
		height: 300upx;
		overflow: hidden;
	}

	.avator .img {
		width: 70%;
		margin: 0 50upx;
	}

	.form {
		padding: 0 100upx;
		margin-top: 40px;
	}

	.inputWrapper {
		width: 100%;
		height: 80upx;
		background: white;
		border-radius: 20px;
		border: 0.5px solid #a3a3a3;
		box-sizing: border-box;
		padding: 0 20px;
		margin-top: 25px;
	}

	.inputWrapper .input {
		width: 100%;
		height: 100%;
		text-align: center;
		font-size: 15px;
	}

	.loginBtn {
		width: 100%;
		height: 80upx;
		background: #42b479;
		border-radius: 50upx;
		margin-top: 50px;
		display: flex;
		justify-content: center;
		align-items: center;

	}

	.loginBtn .btnValue {
		color: white;
	}

	.forgotBtn {
		text-align: center;
		color: #8d8d8d;
		font-size: 15px;
		margin-top: 20px;
	}

	.input {
		flex: 1;
		font-size: 14px;
		color: #666;
		border: 1px #e5e5e5 solid;
		border-radius: 5px;
		padding: 10px;
	}
</style>
