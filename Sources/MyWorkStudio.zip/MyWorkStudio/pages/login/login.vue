<template>
	<view class="content">
		<view class="avatorWrapper">
			<view class="avator">
				<image class="img" src="../../static/jz.png" mode="widthFix"></image>
			</view>
		</view>
		<view class="form">
			<uni-forms ref="form" :modelValue="formData">
				<uni-forms-item name="iphone">
					<input class="input" type="text" value="" v-model="formData.iphone" placeholder="请输入登录手机号" />
				</uni-forms-item>
				<uni-forms-item name="password">
					<input class="input" type="password" value="" v-model="formData.password" placeholder="请输入登录密码" />
				</uni-forms-item>
			</uni-forms>

			<view class="loginBtn" @click="submit">
				<text class="btnValue">登录</text>
			</view>
		</view>


		<view class="register-section">
			<navigator url="../register/register">
				没有账号？点击马上<text>注册</text>!
			</navigator>
		</view>
	</view>
</template>



<script>
	export default {
		data() {
			return {
				formData: {
					iphone: '18277901106',
					password: '123456A@a',
				},
				rules: {
					iphone: {
						rules: [{
							required: true,
							errorMessage: '请输入注册的手机号码'
						}, {
							validateFunction: function(rule, value, data, callback) {
								let iphoneReg = /^1[0-9]{10}$/
								if (!iphoneReg.test(value)) {
									callback('手机号码格式不正确，请重新填写')
									return false
								}
							}
						}]
					},
					password: {
						rules: [{
							required: true,
							errorMessage: '登录密码不能为空',
						}]
					},
				},
			}
		},
		onLoad() {

		},
		methods: {
			//用于小程序二次数据校验失败方法
			onReady() {
				this.$refs.form.setRules(this.rules)
			},
			
			submit() {
				this.$refs.form.validate().then(res => {
					console.log('表单数据信息：', res);
					this.login(res)
				}).catch(err => {
					console.log('表单错误信息：', err);
				})
			},

			req(action, params) {
				uni.showLoading({
					title: '登录中'
				})
				return new Promise((resolve) => {
					uniCloud.callFunction({
						name: 'user-center',
						data: {
							action,
							params
						},
						success: res => {
							uni.hideLoading()
							resolve(res.result);
						},
						fail: res => {
							resolve(res)
						}
					})
				})
			},


			login(e) {

				this.req("login", {
					username: this.formData.iphone,
					password: this.formData.password
				}).then(res => {
					console.log(res)
					uni.setStorageSync('uni_id_token', res.token)
					uni.setStorageSync('nickname', res.userInfo.nickname)
					uni.setStorageSync('user_id', res.userInfo._id)
					uni.setStorageSync('username', res.username)
					uni.switchTab({
						url: '/pages/tabBar/home/home'
					});
				})
				console.log("跳转提醒")
			},




		}
	}
</script>



<style>
	.content {
		width: 100vw;
		height: 100vh;
	}

	.avatorWrapper {
		margin-top: 16px;
		height: 30vh;
		width: 100vw;
		display: flex;
		justify-content: center;
		align-items: flex-end;
	}

	.avator {
		width: 300upx;
		height: 300upx;
		overflow: hidden;
	}

	.avator .img {
		width: 70%;
		margin: 0 50upx;
	}

	.form {
		padding: 0 100upx;
		margin-top: 40px;
	}

	.input {
		flex: 1;
		font-size: 14px;
		color: #666;
		border: 1px #e5e5e5 solid;
		border-radius: 5px;
		padding: 10px;
	}

	.loginBtn {
		width: 100%;
		height: 80upx;
		background: #42b479;
		border-radius: 50upx;
		margin-top: 50px;
		display: flex;
		justify-content: center;
		align-items: center;

	}

	.loginBtn .btnValue {
		color: white;
	}

	.register-section {
		position: absolute;
		left: 0;
		bottom: 50upx;
		width: 100%;
		font-size: 30upx;
		color: #4c4c4c;
		text-align: center;


	}

	.register-section text {
		font-size: 40upx;
		color: #42b479;
		margin-left: 10upx;
	}
</style>
