<template>
	<view class="container">
		<unicloud-db ref="udb" v-slot:default="{data, loading, error, options}" :options="options"
			:collection="collectionList" field="type,amount,remarks,created_at" :where="queryWhere" :getone="true"
			:manual="true">
			<view v-if="error">{{error.message}}</view>
			<view v-else-if="loading">
				<uni-load-more :contentText="loadMore" status="loading"></uni-load-more>
			</view>
			<view v-else-if="data" class="data">
				<view class="amount">
					<text>￥{{data.amount}}</text>
				</view>
				<u-line></u-line>
				<view>
					<view>类型: </view>
					<text>{{options.type_valuetotext[data.type]}}</text>
				</view>
				<view>
					<view>备注: </view>
					<text>{{data.remarks}}</text>
				</view>
				<view>
					<view>日期: </view>
					<uni-dateformat :threshold="[0, 0]" :date="data.created_at" format="yyyy-MM-dd hh:mm:ss"></uni-dateformat>
				</view>
			</view>
		</unicloud-db>
		<view class="btns">
			<button class="revise" type="primary" @click="handleUpdate">编辑</button>
			<button type="warn" class="btn-delete" @click="handleDelete">删除</button>
		</view>
	</view>
</template>

<script>
	// 由schema2code生成，包含校验规则和enum静态数据
	import {
		enumConverter
	} from '../../js_sdk/validator/bill.js'
	const db = uniCloud.database()

	export default {
		data() {
			return {
				queryWhere: '',
				collectionList: "bill",
				loadMore: {
					contentdown: '',
					contentrefresh: '',
					contentnomore: ''
				},
				options: {
					// 将scheme enum 属性静态数据中的value转成text
					...enumConverter
				}
			}
		},
		onLoad(e) {
			this._id = e.id
		},
		onReady() {
			if (this._id) {
				this.queryWhere = '_id=="' + this._id + '"'
			}
		},
		methods: {
			handleUpdate() {
				// 打开修改页面
				uni.navigateTo({
					url: './edit?id=' + this._id,
					events: {
						// 监听修改页面成功修改数据后, 刷新当前页面数据
						refreshData: () => {
							this.$refs.udb.loadData({
								clear: true,
							})
						}
					}
				})
			},
			handleDelete() {
				this.$refs.udb.remove(this._id, {
					success: (res) => {
						uni.showToast({
							icon: 'success',
							title: '删除成功',
							duration: 1000,
							success: function() {
								setTimeout(function() {
									// 删除数据成功后跳转到首页
									uni.reLaunch({
										url: '/pages/tabBar/home/home',
									})
								}, 1000)
							}
						});
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.container {
		padding: 10px;
		color: #4a4a4a 
	}

	.data {
		.amount{ 
			font-size: 80rpx;
			min-height: 100rpx; 
			height: 100rpx;
			width: 50%;
			margin: 20px 5px;
		}
		view {	
			font-size: 24px;
			margin: 15px 5px;

			view {
				font-family: "微软正黑";
				font-size: 22px;
				display: inline-flex;
				margin-right: 10px;
				color: #717171;
			}

			text {	
				font-family: "黑体";
				color: #515151 ;
				font-weight: 900;
			}
		}
	}

	.btns {
		margin-top: 40px;
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;

		.revise {
			background: #42b479;
		}
	}

	.btns button {
		margin-top: 5px;
		font-size: 16px;
		width: 120px;
		line-height: 50px;
		height: 50px;
		
	}

	.btn-delete {
		margin-left: 10px;
	}
</style>
